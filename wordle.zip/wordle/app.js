const express = require('express');
const handlebars = require('express-handlebars');
const cors = require('cors')
const app = express();
const path = require('path');
const fs = require('fs');


//Configurações
    app.use(cors())
    app.use(express.json());
    app.use(express.urlencoded({ extended: true }));

    //Handlebars
    app.engine('handlebars', handlebars.engine())
    app.set('view engine', 'handlebars')

    //Public
    app.use(express.static(path.join(__dirname, 'public')))

    //Rotas
    app.get('/', (req, res) => {
        res.render('home')
    })

    app.get('/word', (req, res) => {
        const filtrado = []
        const array = fs.readFileSync('ListaPalavras.txt').toString().split("\n");
        for(i in array) {
            if (array[i].length === 5) {
                filtrado[i] = array[i]
            }
        }
        var filtradoNull = filtrado.filter(function (i) {return i})
        var item = filtradoNull[Math.floor(Math.random()*filtradoNull.length)];
        res.json(item)
    });

    app.get('/check', (req, res) => {
        const word = req.query.word
        const filtrado = []
        console.log(word)
        const array = fs.readFileSync('ListaPalavras.txt').toString().split("\n");
        for(i in array) {
            if (array[i].length === 5) {
                filtrado[i] = array[i]
            }
        }
        var filtradoNull = filtrado.filter(function (i) {return i})
        var resultado = filtradoNull.indexOf(word)
        if (resultado === -1){
            res.json(resultado)
        } else {
            res.json(resultado)
        }
    })
 
    const PORT = 8081
    app.listen(PORT, () => {
        console.log('Servidor Rodando!')
    })

